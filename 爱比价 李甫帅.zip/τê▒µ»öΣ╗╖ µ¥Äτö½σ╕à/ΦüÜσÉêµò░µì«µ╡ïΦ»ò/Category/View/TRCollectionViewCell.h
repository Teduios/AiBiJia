//
//  TRCollectionViewCell.h
//  TRFindDeals
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRCommodity.h"

@interface TRCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong)TRCommodity *commodity;

@end
