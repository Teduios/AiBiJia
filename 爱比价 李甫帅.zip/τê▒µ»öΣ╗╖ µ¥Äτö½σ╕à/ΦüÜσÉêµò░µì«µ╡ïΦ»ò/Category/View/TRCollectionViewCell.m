//
//  TRCollectionViewCell.m
//  TRFindDeals
//
//  Created by tarena on 15/12/21.
//  Copyright © 2015年 tarena. All rights reserved.
//



#import "TRCollectionViewCell.h"
#import "UIImageView+WebCache.h"//第三方库


@interface TRCollectionViewCell()
@property (weak, nonatomic) IBOutlet UIImageView *commodityImage;
@property (weak, nonatomic) IBOutlet UILabel *titleHighLighter;
@property (weak, nonatomic) IBOutlet UILabel *spprice;
@property (weak, nonatomic) IBOutlet UILabel *siteName;
@property (weak, nonatomic) IBOutlet UILabel *className;
@property (weak, nonatomic) IBOutlet UILabel *commentCounts;
@property (nonatomic,strong)NSString *commentUrl;
@end

@implementation TRCollectionViewCell

- (void)setCommodity:(TRCommodity *)commodity{
    //图片
    [self.commodityImage sd_setImageWithURL:[NSURL URLWithString:commodity.sppic] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
    
    //对取到的还有HTML标签的标题进行处理
    
    self.titleHighLighter.text = [self removeHTML2:commodity.TitleHighLighter];
    //self.titleHighLighter.text = commodity.TitleHighLighter;
    //NSLog(@"获取标题%@",commodity.TitleHighLighter);
    self.spprice.text = commodity.spprice;
    self.siteName.text = commodity.siteName;
    self.className.text = commodity.className;
    self.commentCounts.text = commodity.commentCounts;
    self.commentUrl = commodity.commentUrl;
    
}

- (NSString *)removeHTML2:(NSString *)html{
    
    NSArray *components = [html componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    
    
    
    NSMutableArray *componentsToKeep = [NSMutableArray array];
    
    for (int i = 0; i < [components count]; i = i + 2) {
        
        [componentsToKeep addObject:[components objectAtIndex:i]];
        
    }
    
    
    
    NSString *plainText = [componentsToKeep componentsJoinedByString:@""];
    
    return plainText;
    
}
- (IBAction)ToCommoentURL:(id)sender {
    //[[NSNotificationCenter defaultCenter]postNotificationName:@"commentBtnClick" object:nil userInfo:@{@"commentUrl":self.commentUrl}];
}

@end
