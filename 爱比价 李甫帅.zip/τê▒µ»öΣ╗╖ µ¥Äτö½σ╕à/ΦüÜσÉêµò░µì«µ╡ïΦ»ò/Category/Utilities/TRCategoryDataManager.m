//
//  TRDataManager.m
//  shopping
//
//  Created by pikaqiufan on 16/1/6.
//  Copyright © 2016年 bwp. All rights reserved.
//

#import "TRCategoryDataManager.h"
#import "TRCategoryList.h"

@implementation TRCategoryDataManager
static NSArray *_categoryListArray = nil;
+ (NSArray *)getCategoryList{
    if (!_categoryListArray) {
        _categoryListArray = [[self alloc]getPlistData:@"category.plist" withClass:[TRCategoryList class]];
    }
    return _categoryListArray;
}

- (NSArray *)getPlistData:(NSString *)plistName withClass:(Class) modelClass{
    //从plistName中读取数据
    NSString *plistPath = [[NSBundle mainBundle]pathForResource:plistName ofType:nil];
    //    array[Dic,Dic.....]
    NSArray *array = [NSArray arrayWithContentsOfFile:plistPath];
    //循环转换:Dictionary->modelClass
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        //创建modelClass对象
        id modelInstance = [[modelClass alloc]init];
        [modelInstance setValuesForKeysWithDictionary:dic];
        [mutableArray addObject:modelInstance];
    }
    return [mutableArray copy];
}
@end
