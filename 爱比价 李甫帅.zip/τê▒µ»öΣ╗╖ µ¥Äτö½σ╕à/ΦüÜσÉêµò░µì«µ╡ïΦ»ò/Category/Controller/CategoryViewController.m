//
//  CategoryViewController.m
//  shopping
//
//  Created by pikaqiufan on 16/1/8.
//  Copyright © 2016年 bwp. All rights reserved.
//

#import "CategoryViewController.h"
#import "TRCategoryDataManager.h"
#import "TRCategoryList.h"
#import "TRCollectionViewCell.h"
#import "JHAPISDK.h"
#import "JHOpenidSupplier.h"
#import "TRCommodity.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"
#import "TRDataManager.h"
#import "TRDetailViewController.h"

@interface CategoryViewController () <UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout, MBProgressHUDDelegate>

@property (weak, nonatomic) IBOutlet UITableView *categoryTableView;
@property (weak, nonatomic) IBOutlet UICollectionView *categoryCollection;
@property (nonatomic, strong) NSArray *categoryList;
/**声明属性 返回的数据*/
@property (nonatomic, strong)id responseObject;
/**存储返回的数据*/
@property (nonatomic, strong)NSMutableArray *commodityArray;

/** 请求返回的页数 */
@property (nonatomic, assign)int pageNum;

/** 请求的关键词 */
@property (nonatomic, strong)NSString *keyword;

@property (nonatomic, strong)NSIndexPath *indexPathSC;

@end

@implementation CategoryViewController
- (NSMutableArray *)commodityArray{
    if (!_commodityArray) {
        _commodityArray = [NSMutableArray array];
    }
    return _commodityArray;
}

- (NSArray *)categoryList {
    if(_categoryList == nil) {
        _categoryList = [TRCategoryDataManager getCategoryList];
    }
    return _categoryList;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    self.pageNum = 1;
    self.keyword = @"潮流女装";
    
    self.categoryTableView.showsVerticalScrollIndicator = NO;

    [self.categoryCollection registerNib:[UINib nibWithNibName:@"TRCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"Cell1"];
    //添加 上拉控件
    [self addRefreshContrl];
    [self sendDataTest];

   // [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(toCommentH5:) name:@"commentBtnClick" object:nil];
    
}
//- (void)toCommentH5:(NSNotification *)noti{
//    CommentViewController *comVC = [CommentViewController new];
//    comVC.commentUrl = noti.userInfo[@"commentUrl"];
//    [self presentViewController:comVC animated:YES completion:nil];
//}

#pragma mark - 上拉控件
- (void)addRefreshContrl{
    self.categoryCollection.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(sendMoreData)];
}
#pragma mark - tableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.categoryList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuseIdentifier = @"reuseIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    }
    tableView.separatorStyle = NO;
    // 设置cell背景
    cell.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_cell_normal_h"]];
    // 设置cell被选中时的背景
    cell.selectedBackgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg_cell_redline"]];
    
    cell.textLabel.textColor = [UIColor blackColor];
    cell.textLabel.textAlignment = NSTextAlignmentCenter;
    // 设置cell内容
    TRCategoryList *categoryArray = self.categoryList[indexPath.row];
    cell.textLabel.font = [UIFont systemFontOfSize:12];
    cell.textLabel.text = categoryArray.className;
    
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TRCategoryList *categoryArray = self.categoryList[indexPath.row];
    self.keyword = categoryArray.className;
    //NSLog(@"%@", self.keyword);
    [tableView scrollToNearestSelectedRowAtScrollPosition:UITableViewScrollPositionTop animated:YES];
    [self.commodityArray removeAllObjects];
    [self sendDataTest];
    
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}


#pragma mark - 发送请求
/**发送数据*/
- (void)sendDataTest{
    self.pageNum = 1;
    [self sendRequestToServer];
    [self showWithLabel];
}

/** 加载更多的数据 */
- (void)sendMoreData{
    self.pageNum ++;
    [self sendRequestToServer];
}

/** 请求服务器返回数据*/
- (void)sendRequestToServer{
    //NSString *path = @"http://japi.juhe.cn/manmanmai/simple.from";
    //NSString *path = @"http://japi.juhe.cn/manmanmai/allsites.from";
    NSString *path = @"http://japi.juhe.cn/manmanmai/complex.from";
    NSString *api_id = @"137";
    NSString *method = @"GET";
    
    NSDictionary *param = @{@"keyword":self.keyword,@"PageNum":@(self.pageNum),@"PageSize":@10};
    JHAPISDK *juheapi = [JHAPISDK shareJHAPISDK];
    [juheapi executeWorkWithAPI:path APIID:api_id Parameters:param Method:method Success:^(id responseObject) {
        if ([[param objectForKey:@"dtype"] isEqualToString:@"json"]) {
            NSLog(@"***xml*** \n %@", responseObject);
        }else{
            int error_code = [[responseObject objectForKey:@"error_code"] intValue];
            if (!error_code) {
                NSLog(@" %@", responseObject);
            }else{
                NSLog(@" %@", responseObject);
            }
            
            NSArray *resultArray = [TRDataManager parseCommodityResponseObjiect:responseObject];
            
            //添加数据到commodityArray
            [self.commodityArray addObjectsFromArray:resultArray];
            
            // [self.categoryCollection scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UICollectionViewScrollPositionTop animated:YES];
            //刷新tableView
            [self.categoryCollection reloadData];
            
            //设置collegetionView回到顶部
            [self.categoryCollection setContentSize:CGSizeMake(0, 0)];
      
            //停止上拉控件的动画
            [self.categoryCollection.mj_footer endRefreshing];
  
        }
        
        
    } Failure:^(NSError *error) {
        NSLog(@"error:   %@",error.description);
        
        //创建MBProgressHUD控件
        MBProgressHUD *hub = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        
        //设置属性
        hub.mode = MBProgressHUDModeText;
        hub.labelText = @"网络繁忙,请稍后再试";
        hub.margin = 10;
        
        //延迟时间
        hub.removeFromSuperViewOnHide = YES;
        [hub hide:YES afterDelay:3];
        
        //停止上拉控件动画
        [self.categoryCollection.mj_footer endRefreshing];
    }];
    

}

- (void)showWithLabel{
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    
    HUD.delegate = self;
    HUD.labelText = @"正在拼命的加载...";
    
    [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
}

- (void)myTask {
    // Do something usefull in here instead of sleeping ...
    sleep(2);
}


#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.commodityArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    TRCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell1" forIndexPath:indexPath];
    TRCommodity *commodity = self.commodityArray[indexPath.row];
    cell.commodity = commodity;
    self.indexPathSC = indexPath;
    return cell;
    

}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    TRDetailViewController *detailVC = [TRDetailViewController new];
    TRCommodity *commodit = self.commodityArray[indexPath.row];
    //h5传参
    detailVC.spurl = commodit.spurl;
    
    [self presentViewController:detailVC animated:YES completion:nil];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(collectionView.bounds.size.width*0.5-10, collectionView.bounds.size.height*0.45);
}





@end
