//
//  TRCategoryList.h
//  shopping
//
//  Created by pikaqiufan on 16/1/6.
//  Copyright © 2016年 bwp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRCategoryList : NSObject

@property (nonatomic, strong)NSString *className;

@end
