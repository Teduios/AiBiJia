//
//  AppDelegate.h
//  聚合数据测试
//
//  Created by milo on 16/1/2.
//  Copyright © 2016年 milo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

